package com.techsum.inamigos.model

data class VoteForDesignItemX(
    val id: String,
    val url: String
)