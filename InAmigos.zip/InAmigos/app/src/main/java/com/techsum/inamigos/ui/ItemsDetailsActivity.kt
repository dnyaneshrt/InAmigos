package com.techsum.inamigos.ui

import androidx.appcompat.app.AppCompatActivity

class ItemsDetailsActivity : AppCompatActivity() {

}