package com.techsum.inamigos.ui

import androidx.fragment.app.Fragment

class MyDesignFragment : Fragment() {
}