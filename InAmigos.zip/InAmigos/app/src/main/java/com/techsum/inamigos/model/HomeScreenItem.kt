package com.techsum.inamigos.model

data class HomeScreenItem(
    val id: String,
    val url: String
)